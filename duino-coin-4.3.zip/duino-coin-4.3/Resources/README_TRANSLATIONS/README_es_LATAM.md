<!--
*** Official Duino Coin LATAM README
*** by revoxhere, 2019-2022
*** translated by Technopy311
*** Last update by kaytipooficial
-->

<a href="https://duinocoin.com">
  <img src="https://github.com/revoxhere/duino-coin/blob/master/Resources/duco.png?raw=true" width="215px" align="right" />
</a>

<h1>
  <a href="https://duinocoin.com">
    <img src="https://github.com/revoxhere/duino-coin/blob/master/Resources/ducobanner.png?raw=true" width="430px" />
  </a>
  <br>
  <a href="https://github.com/revoxhere/duino-coin/blob/master/README.md">
    <img src="https://img.shields.io/badge/English-ff8502.svg?style=for-the-badge" /></a>
  <a href="https://github.com/revoxhere/duino-coin/blob/master/Resources/README_TRANSLATIONS/README_es_LATAM.md">
    <img src="https://img.shields.io/badge/-Espa%C3%B1ol-ff7421?style=for-the-badge" /></a>
  <a href="https://github.com/revoxhere/duino-coin/blob/master/Resources/README_TRANSLATIONS/README_zh_TW.md">
    <img src="https://img.shields.io/badge/繁體中文-ff6137.svg?style=for-the-badge" /></a>
  <a href="https://github.com/revoxhere/duino-coin/blob/master/Resources/README_TRANSLATIONS/README_zh_CN.md">
    <img src="https://img.shields.io/badge/简体中文-ff6137.svg?style=for-the-badge" /></a>
  <a href="https://github.com/revoxhere/duino-coin/blob/master/Resources/README_TRANSLATIONS/README_pl_PL.md">
    <img src="https://img.shields.io/badge/Polski-ff4b4c.svg?style=for-the-badge" /></a>
  <a href="https://github.com/revoxhere/duino-coin/blob/master/Resources/README_TRANSLATIONS/README_ru_RU.md">
    <img src="https://img.shields.io/badge/русский-ff3062.svg?style=for-the-badge" /></a>
  <a href="https://github.com/revoxhere/duino-coin/blob/master/Resources/README_TRANSLATIONS/README_tr_TR.md">
    <img src="https://img.shields.io/badge/Türk-ff0079.svg?style=for-the-badge" /></a>
  <a href="https://github.com/revoxhere/duino-coin/blob/master/Resources/README_TRANSLATIONS/README_th_TH.md">
    <img src="https://img.shields.io/badge/-%E0%B9%84%E0%B8%97%E0%B8%A2-ff0092.svg?style=for-the-badge" /></a>
  <a href="https://github.com/revoxhere/duino-coin/blob/master/Resources/README_TRANSLATIONS/README_pt_BR.md">
    <img src="https://img.shields.io/badge/-Portugu%C3%AAs-ff009a.svg?style=for-the-badge" /></a>
  <a href="https://github.com/revoxhere/duino-coin/blob/master/Resources/README_TRANSLATIONS/README_de_DE.md">
    <img src="https://img.shields.io/badge/-Deutsch-ff00b2.svg?style=for-the-badge" /></a>
  <a href="https://github.com/revoxhere/duino-coin/blob/master/Resources/README_TRANSLATIONS/README_id_ID.md">
    <img src="https://img.shields.io/badge/-bahasa Indonesia-ff00ca.svg?style=for-the-badge" /></a>
  <a href="https://github.com/revoxhere/duino-coin/blob/master/Resources/README_TRANSLATIONS/README_kr_KR.md">
    <img src="https://img.shields.io/badge/한국어-ff0ae3.svg?style=for-the-badge" /></a>
  <a href="https://github.com/revoxhere/duino-coin/blob/master/Resources/README_TRANSLATIONS/README_sk_SK.md">
    <img src="https://img.shields.io/badge/slovensky-ff0ae3.svg?style=for-the-badge" /></a>
  <a href="https://github.com/revoxhere/duino-coin/blob/master/Resources/README_TRANSLATIONS/README_it_IT.md">
    <img src="https://img.shields.io/badge/italiano-ff0ae3.svg?style=for-the-badge" /></a>
  <a href="https://github.com/revoxhere/duino-coin/blob/master/Resources/README_TRANSLATIONS/README_cz_CZ.md">
    <img src="https://img.shields.io/badge/%C4%8Desky-ff4b4c.svg?style=for-the-badge" /></a>
  <a href="https://github.com/revoxhere/duino-coin/blob/master/Resources/README_TRANSLATIONS/README_in_HI.md">
    <img src="https://img.shields.io/badge/-Hindi-orange?style=for-the-badge" /></a>
  <a href="https://github.com/revoxhere/duino-coin/blob/master/Resources/README_TRANSLATIONS/README_ja_JP.md">
    <img src="https://img.shields.io/badge/-日本語-orange?style=for-the-badge" /></a>
  <a href="https://github.com/revoxhere/duino-coin/blob/master/Resources/README_TRANSLATIONS/README_fi_FI.md">
    <img src="https://img.shields.io/badge/finnish-121212.svg?style=for-the-badge" /></a>
</h1>
<a href="https://wallet.duinocoin.com">
  <img src="https://img.shields.io/badge/Online Wallet-a202ff.svg?style=for-the-badge&logo=Web" /></a>
<a href="https://play.google.com/store/apps/details?id=com.protothis.duinocoin">
  <img src="https://img.shields.io/badge/Android App-eb00cb.svg?style=for-the-badge&logo=Android" /></a>
<a href="https://github.com/fahimrahmanbooom/Duino-Coin_iOS_App">
  <img src="https://img.shields.io/badge/iOS App-eb00cb.svg?style=for-the-badge&logo=Apple" /></a>
<a href="https://github.com/revoxhere/duino-coin/blob/gh-pages/assets/whitepaper.pdf">
  <img src="https://img.shields.io/badge/whitepaper-ff0095.svg?style=for-the-badge&logo=Academia" /></a>
<a href="https://youtu.be/im0Tca7EjrA">
  <img src="https://img.shields.io/badge/Video-Watch-ff0064.svg?style=for-the-badge&logo=Youtube" /></a>
<a href="https://discord.gg/kvBkccy">
  <img src="https://img.shields.io/discord/677615191793467402.svg?color=ff283a&label=Discord&logo=Discord&style=for-the-badge" /></a>
<a href="https://github.com/revoxhere/duino-coin/releases/latest">
  <img src="https://img.shields.io/badge/release-latest-ff640a.svg?style=for-the-badge" /></a>
<br>

<h3>
  Duino-Coin es una moneda que puede ser minada con Arduinos, placas ESP8266/32, Raspberry Pis, computadoras, y mucho más
  (incluyendo routers Wi-Fi, smart TVs, smartphones, smartwatches, SBCs, MCUs o incluso GPUs)
</h3>


| Características Clave	| Especificaciones Técnicas	| (Algunas de las tantas) Placas Soportadas |
|-|-|-|
| 💻 Soportado por un gran número de plataformas<br>👥 Una comunidad de rápido crecimiento<br>💱 Facil de usar e intercambiar<br>(en DUCO Exchange, JustSwap, SushiSwap)<br>🌎 Disponible donde sea<br>:new: Proyecto totalmente original y de código abierto<br>🌳 Amigable con principiantes y con el medio ambiente<br>💰 De bajo costo y facil minado | ⚒️ Algoritmo: DUCO-S1<br>♐ Recompensas: Soportadas por el "Sistema Kolka"<br>ayudando a recompensar justamente a los mineros<br>⚡ Tiempo de transacción: Instantáneo<br>🪙 Suministro de monedas: Infinito<br>(Con quema de monedas)<br>🔤 Ticker: DUCO (ᕲ)<br>🔢 Decimales: Hasta 20 | ♾️ Arduinos<br>(Uno, Nano, Mega, Due, Pro Mini, etc.)<br>📶 ESP8266s<br>(NodeMCU, Wemos, etc.)<br>📶 ESP32s<br>(ESP-WROOM, ESP32-CAM, etc.)<br>🍓 Raspberry Pis<br>(1, 2, Zero (W/WH), 3, 4, Pico, 400)<br>🍊 Orange Pis<br>(Zero, Zero 2, PC, Plus, etc.)<br>⚡ Placas Teensy 4.1 |


## Para Comenzar

#### La forma más fácil para comenzar con Duino-Coin es descargar [la ultima versión](https://github.com/revoxhere/duino-coin/releases/latest) para tu sistema operativo.

Después de descargar la versión, extrae y ejecuta el programa deseado.<br>
No se requieren dependencias.

Si necesitas ayuda, puedes mirar las guías oficiales para comenzar <a href="https://duinocoin.com/getting-started">en el sitio web oficial</a>.<br>
Las preguntas más frecuentes y la ayuda para solucionar problemas se pueden encontrar en las [Wikis](https://github.com/revoxhere/duino-coin/wiki).<br>

#### Linux  (instalación manual)

```BASH
sudo apt update
sudo apt install python3 python3-pip git python3-pil python3-pil.imagetk -y # Install dependencies
git clone https://github.com/revoxhere/duino-coin # Clone Duino-Coin repository
cd duino-coin
python3 -m pip install -r requirements.txt # Install pip dependencies
```

Luego de hacer esto, ya puedes ejecutar el programa deseado (Ej. `python3 PC_Miner.py`).

#### Windows (instalación manual)

1. Descarga e instala [Python 3](https://www.python.org/downloads/) (Asegúrate de tener añadidos Python y PIP a tu PATH)
2. Descarga [el repositorio de Duino-Coin](https://github.com/revoxhere/duino-coin/archive/master.zip)
3. Extrae el archivo zip que descargaste y abre la carpeta con el símbolo del sistema
4. En el símbolo del sistema escribe `py -m pip install -r requirements.txt` para instalar las dependencias pip requeridas

Luego de hacer esto, ya puedes ejecutar el software (haciendo doble click en el archivo `.py` o poniendo `py PC_Miner.py` en el símbolo del sistema).

#### Raspberry Pi (instalación automática)

```BASH
wget https://raw.githubusercontent.com/revoxhere/duino-coin/master/Tools/duco-install-rpi.sh
sudo chmod a+x duco-install-rpi.sh
./duco-install-rpi.sh
```

## DUCO, wDUCO, bscDUCO, maticDUCO & celoDUCO

Duino-Coin es una moneda híbrida que da soporte tanto a formas centralizadas como descentralizadas de almacenar fondos. Los Duino-Coins pueden convertirse en wDUCO, bscDUCO u otros, que son los mismos Duino-Coins pero "envueltos" (almacenados) en otras redes como tokens. Un tutorial de ejemplo sobre el uso de wDUCO está disponible en el [wDUCO wiki](https://github.com/revoxhere/duino-coin/wiki/wDUCO-tutorial). Las monedas pueden ser envueltas directamente desde su Web Wallet - haga clic en el botón Wrap Coins para empezar.

## Desarrollo

Las contribuciones son lo que hacen que la comunidad de código abierto sea un lugar increíble para aprender, inspirarse y crear.<br>
Cualquier contribución que haces al proyecto de Duino-Coin son gratamente apreciadas.

¿Como ayudar?

*   Bifurca el proyecto (fork)
*   Crea tu rama de desarrollo
*   Sube tus cambios (commit)
*   Asegúrate de que todo funciona como debería
*   Abre una petición de subida (pull request)

El código fuente del servidor, documentación para las peticiones a la API y librerías oficiales para desarrollar tus propias apps para Duino-Coin están disponibles están disponibles en la rama de [herramientas útiles](https://github.com/revoxhere/duino-coin/tree/useful-tools)


## Version 4.0 objetivo de recompensas

Capturado con un multiplicador normal (no multiplicador de fin de semana)
| Dispositivo                    | Hashrate               | Hilos   | DUCO/día | Potencia usada |
|--------------------------------|------------------------|---------|----------|----------------|
| Arduino                        | 343 H/s                | 1       | 12       | <0.5 W
| ESP32                          | 170-180 kH/s           | 2       | 10       | 1.5-2 W
| ESP32-S2/C3                    | 85-96 kH/s             | 1       | 8        | 1-1.5 W
| ESP8266                        | 66 kH/s                | 1       | 6        | 1-1.5 W
| Raspberry Pi 4 (Bajo)          | 1 MH/s (no hash rápido)| 4       | 6-7      | 6.5 W
| Raspberry Pi 4 (Medio)         | 5.4 MH/s (has rápido)  | 4       | 7-8      | 6.5 W
| Computadores de bajos recursos |                        | 4       | 4-6      | -
| Computadores de medios recursos|                        | 4-8     | 6-10     | -
| Computadores de altos recursos |                        | 8+      | 10-12    | -

<details>
  <summary><b>Otros dispositivos testeados y sus benchmarks</b></summary>
  
Tenga en cuenta que la columna DUCO/día se ha eliminado desde que la versión 4.0 cambió el sistema de recompensas.
| Dispositivp/CPU/SBC/MCU/chip                              | Tasa de hash promedio<br>(todos los hilos) | Hilos de minado   | Potencia usada |
|-----------------------------------------------------------|--------------------------------------------|-------------------|----------------|
| Raspberry Pi Pico                                         | 5 kH/s                                     | 1                 | 0.3 W          |
| Raspberry Pi Zero                                         | 18 kH/s                                    | 1                 | 1.1 W          |
| Raspberry Pi 3 **(32bit)**                                | 440 kH/s                                   | 4                 | 5.1 W          |
| Raspberry Pi 4 **(32bit)**                                | 740 kH/s                                   | 4                 | 6.4 W          |
| Raspberry Pi 4 **(64bit, hash rápido)**                   | 6.8 MH/s                                   | 4                 | 6.4 W          |
| ODROID XU4                                                | 1.0 MH/s                                   | 8                 | 5 W            |
| Atomic Pi                                                 | 690 kH/s                                   | 4                 | 6 W            |
| Orange Pi Zero 2                                          | 740 kH/s                                   | 4                 | 2.55 W         |
| Khadas Vim 2 Pro                                          | 1.12 MH/s                                  | 8                 | 6.2 W          |
| Libre Computers Tritium H5CC                              | 480 kH/s                                   | 4                 | 5 W            |
| Libre Computers Le Potato                                 | 410 kH/s                                   | 4                 | 5 W            |
| Pine64 ROCK64                                             | 640 kH/s                                   | 4                 | 5 W            |
| Intel Celeron G1840                                       | 1.25 MH/s                                  | 2                 | 53 W           |
| Intel Core i5-2430M                                       | 1.18 MH/s                                  | 4                 | 35 W           |
| Intel Core i5-3230M                                       | 1.52 MH/s                                  | 4                 | 35 W           |
| Intel Core i5-5350U                                       | 1.35 MH/s                                  | 4                 | 15 W           |
| Intel Core i5-7200U                                       | 1.62 MH/s                                  | 4                 | 15 W           |
| Intel Core i5-8300H                                       | 3.67 MH/s                                  | 8                 | 45 W           |
| Intel Core i3-4130                                        | 1.45 MH/s                                  | 4                 | 54 W           |
| AMD Ryzen 5 2600                                          | 4.9 MH/s                                   | 12                | 65 W           |
| AMD Ryzen R1505G **(hash rápido)**                        | 8.5 MH/s                                   | 4                 | 35 W           |
| Intel Core i7-11370H **(hash rápido)**                    | 17.3 MH/s                                  | 8                 | 35 W           |
| Realtek RTD1295                                           | 490 kH/s                                   | 4                 | -              |
| Realtek RTD1295 **(hash rápido)**                         | 3.89 MH/s                                  | 4                 | -              |

</details>




## Programas hechos por la comunidad

### Ten en cuenta que estos programas no han sido desarrollados por nosotros y que no damos ninguna garantía de que usarlos no resultarán en un baneo de cuenta. Trátelos como una curiosidad.

  ### Otros mineros que trabajan con Duino-Coin:
  *   [Dockerized Duino-Coin Miner](https://github.com/simeononsecurity/docker-duino-coin) - Una versión Dockerizada del Minero Duino-Coin
  *   :point_right: [**RP2040-HAT-MINING-C**](https://github.com/Wiznet/RP2040-HAT-MINING-C) - **WIZnet RP2040** stack minero
  *   [DuinoCoinEthernetMiner](https://github.com/Pumafron/DuinoCoinEthernetMiner) - Minero Arduino Ethernet Shield por Pumafron
  *   [STM8 DUCO Miner](https://github.com/BBS215/STM8_DUCO_miner) - STM8S firmware para minar DUCO por BBS215
  *   [DuinoCoinbyLabVIEW](https://github.com/ericddm/DuinoCoinbyLabVIEW) - minero para familia LabVIEW por ericddm
  *   [Duino-JS](https://github.com/Hoiboy19/Duino-JS) - un minero JavaScript que puedes implementar fácilmente en tu sitio web por Hoiboy19
  *   [Mineuino](https://github.com/VatsaDev/Mineuino) - monetizador de sitios web con Duino por VatsaDev
  *   [hauchel's duco-related stuff repository](https://github.com/hauchel/duco/) - Colección de varios códigos para minar DUCO en otros microcontroladores
  *   [duino-coin-php-miner](https://github.com/ricardofiorani/duino-coin-php-miner) - Minero Dockerizado en PHP por ricardofiorani
  *   [duino-coin-kodi](https://github.com/SandUhrGucker/duino-coin-kodi) - Add-on de minado para Kodi Media Center por SandUhrGucker
  *   [MineCryptoOnWifiRouter](https://github.com/BastelPichi/MineCryptoOnWifiRouter) - script en Python para minar en routers Wi-Fi por BastelPichi
  *   [Duino-Coin_Android_Cluster Miner](https://github.com/DoctorEenot/DuinoCoin_android_cluster) - mina con menos conecciones en varios dispositivos por DoctorEenot
  *   [ESPython DUCO Miner](https://github.com/fabiopolancoe/ESPython-DUCO-Miner) - minero en MicroPython para placas ESP por fabiopolancoe
  *   [DUCO Miner for Nintendo 3DS](https://github.com/BunkerInnovations/duco-3ds) - minero en Python para Nintendo 3DS por PhereloHD & HGEpro
  *   [Dockerized DUCO Miner](https://github.com/Alicia426/Dockerized_DUCO_Miner_minimal) - Minero en Docker por Alicia426
  *   [NodeJS-DuinoCoin-Miner](https://github.com/LDarki/NodeJS-DuinoCoin-Miner/) - minero simple en Node.JS por LDarki
  *   [d-cpuminer](https://github.com/phantom32-0/d-cpuminer) - minero en C puro por phantom32 & revoxhere
  *   [Go Miner](https://github.com/yippiez/go-miner) por yippiez
  *   [ducominer](https://github.com/its5Q/ducominer) por its5Q
  *   [Directorio de mineros no oficiales](https://github.com/revoxhere/duino-coin/tree/master/Unofficial%20miners)
      *   [Julia Miner](https://github.com/revoxhere/duino-coin/blob/master/Unofficial%20miners/Julia_Miner.jl) por revoxhere
      *   [Ruby Miner](https://github.com/revoxhere/duino-coin/blob/master/Unofficial%20miners/Ruby_Miner.rb) por revoxhere
      *   [Minimal Python Miner (DUCO-S1)](https://github.com/revoxhere/duino-coin/blob/master/Unofficial%20miners/Minimal_PC_Miner.py) por revoxhere
      *   [Teensy 4.1 code for Arduino IDE](https://github.com/revoxhere/duino-coin/blob/master/Unofficial%20miners/Teensy_code/Teensy_code.ino) por joaquinbvw

  ### Otras herramientas:
  *   [Duinogotchi](https://github.com/OSRdesign/duinogotchi) - Proyecto de Duino-Coin mascotas virtuales por ricaun
  *   [Duino Miner](https://github.com/g7ltt/Duino-Miner) - Archivos y documentación del minero DUCO basado en Arduino Nano por g7ltt
  *   [DUINO Mining Rig](https://repalmakershop.com/pages/duino-mining-rig) - Archivos 3D, diseños de PCB e instrucciones para crear tu propio Duino rig por ReP_AL
  *   [DuinoCoin-balance-Home-Assistant](https://github.com/NL647/DuinoCoin-balance-Home-Assistant) - add-on para Home Assistant mostrando tu saldo por NL647
  *   [ducopanel](https://github.com/ponsato/ducopanel) - un app GUI para controlar tus mineros Duino-Coin por ponsato
  *   [Duino AVR Monitor](https://www.microsoft.com/store/apps/9NJ7HPFSR9V5) - app GUI de Windows para monitorear dispositivos AVR minando DUCO por niknak
  *   [Duino-Coin Arduino library](https://github.com/ricaun/arduino-DuinoCoin) por ricaun
  *   [DuinoCoinI2C](https://github.com/ricaun/DuinoCoinI2C) - Usa ESP8266/ESP32 como maestros para Arduinos por ricaun
  *   [Duino-Coin Mining Dashboard](https://lulaschkas.github.io/duco-mining-dashboard/) y ayudante de solución de problemas por Lulaschkas
  *   [duco-miners](https://github.com/dansinclair25/duco-miners) panel de control de minado CLI hecho por dansinclair25
  *   [Duco-Coin Symbol Icon ttf](https://github.com/SandUhrGucker/Duco-Coin-Symbol-Icon-ttf-.h) por SandUhrGucker
  *   [DUCO Monitor](https://siunus.github.io/duco-monitor/) sitio web de estadísticas de cuentas por siunus
  *   [Duino Stats](https://github.com/Bilaboz/duino-stats) bot oficial de Discord por Bilaboz
  *   [DuCoWallet](https://github.com/viktor02/DuCoWallet) Wallet GUI por viktor02
  *   [Duco-widget-ios](https://github.com/naphob/duco-widget-ios) - un widget Duino-Coin para iOS por Naphob
  *   [Duino Lookup](https://axorax.github.io/duino-lookup/) por axorax

  Tambien puedes ver una lista similar en el [sitio web](https://duinocoin.com/apps).


## Licencia

Duino-Coin está distribuído principalmente bajo la licencia MIT. Mira el archivo `LICENSE` para más información.
Algunos archivos de terceros incluídos pueden tener licencias diferentes - por favor checa sus archivos `LICENSE` (usualmente en la parte superior del codigo fuente).

## Términos de servicio

Nuestros términos de servicio están disponibles aquí: <a href="https://duinocoin.com/terms">duinocoin.com/terms</a><br/>

## Políticas de privacidad

Nuestra política de privacidad está disponible aquí: <a href="https://duinocoin.com/privacy">duinocoin.com/privacy</a><br/>

## Aviso legal

Nuestro aviso legal está disponible aquí: <a href="https://duinocoin.com/disclaimer">duinocoin.com/disclaimer</a><br/>


## Mantenedores activos del proyecto

Originalmente creado y mantenido por [@revoxhere](https://github.com/revoxhere).
Muchas gracias a todos los [contribuidores](https://github.com/revoxhere/duino-coin/graphs/contributors) que han ayudado a desarrollar el proyecto Duino-Coin.
Visita [duinocoin.com/team.html](https://duinocoin.com/team.html) para obtener mas información sobre el equipo de Duino-Coin.

<hr>

Enlace del Proyecto: [https://github.com/revoxhere/duino-coin/](https://github.com/revoxhere/duino-coin/)
<br/>
Enlace del Sitio Web: [https://duinocoin.com/](https://duinocoin.com/)
<br/>
Sitio Web del Estado de Duino-Coin: [https://status.duinocoin.com](https://status.duinocoin.com)
