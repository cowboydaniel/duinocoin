<a href="https://duinocoin.com">
  <img src="https://github.com/revoxhere/duino-coin/blob/master/Resources/duco.png?raw=true" width="215px" align="right" />
</a>
<h1>
  <a href="https://duinocoin.com">
    <img src="https://github.com/revoxhere/duino-coin/blob/master/Resources/ducobanner.png?raw=true" width="430px" />
  </a>
  <br>

  <br>
  <a href="https://github.com/revoxhere/duino-coin/blob/master/README.md">
    <img src="https://img.shields.io/badge/English-ff8502.svg?style=for-the-badge" /></a>
  <a href="https://github.com/revoxhere/duino-coin/blob/master/Resources/README_TRANSLATIONS/README_es_LATAM.md">
    <img src="https://img.shields.io/badge/-Espa%C3%B1ol-ff7421?style=for-the-badge" /></a>
  <a href="https://github.com/revoxhere/duino-coin/blob/master/Resources/README_TRANSLATIONS/README_zh_CN.md">
    <img src="https://img.shields.io/badge/简体中文-ff6137.svg?style=for-the-badge" /></a>
  <a href="https://github.com/revoxhere/duino-coin/blob/master/Resources/README_TRANSLATIONS/README_pl_PL.md">
    <img src="https://img.shields.io/badge/Polski-ff4b4c.svg?style=for-the-badge" /></a>
  <a href="https://github.com/revoxhere/duino-coin/blob/master/Resources/README_TRANSLATIONS/README_ru_RU.md">
    <img src="https://img.shields.io/badge/русский-ff3062.svg?style=for-the-badge" /></a>
  <a href="https://github.com/revoxhere/duino-coin/blob/master/Resources/README_TRANSLATIONS/README_tr_TR.md">
    <img src="https://img.shields.io/badge/Türk-ff0079.svg?style=for-the-badge" /></a>
  <a href="https://github.com/revoxhere/duino-coin/blob/master/Resources/README_TRANSLATIONS/README_th_TH.md">
    <img src="https://img.shields.io/badge/-%E0%B9%84%E0%B8%97%E0%B8%A2-ff0092.svg?style=for-the-badge" /></a>
  <a href="https://github.com/revoxhere/duino-coin/blob/master/Resources/README_TRANSLATIONS/README_pt_BR.md">
    <img src="https://img.shields.io/badge/-Portugu%C3%AAs-ff00ad.svg?style=for-the-badge" /></a>
  <a href="https://github.com/revoxhere/duino-coin/blob/master/Resources/README_TRANSLATIONS/README_de_DE.md">
    <img src="https://img.shields.io/badge/-Deutsch-ff00c8.svg?style=for-the-badge" /></a>
  <a href="https://github.com/revoxhere/duino-coin/blob/master/Resources/README_TRANSLATIONS/README_id_ID.md">
    <img src="https://img.shields.io/badge/-bahasa Indonesia-ff0ae3.svg?style=for-the-badge" /></a>
    <img src = "https://img.shields.io/badge/-Korean-blueviolet.svg?style=for-the-badge"></a>
  <a href="https://github.com/revoxhere/duino-coin/blob/master/Resources/README_TRANSLATIONS/README_ja_JP.md">
    <img src="https://img.shields.io/badge/-日本語-orange?style=for-the-badge" /></a>
  <a href="https://github.com/revoxhere/duino-coin/blob/master/Resources/README_TRANSLATIONS/README_fi_FI.md">
    <img src="https://img.shields.io/badge/finnish-121212.svg?style=for-the-badge" /></a>
<br>

  <a href="https://wallet.duinocoin.com">
  <img src="https://img.shields.io/badge/Online Wallet-a202ff.svg?style=for-the-badge&logo=Web" /></a>
<a href="https://play.google.com/store/apps/details?id=com.pripun.duinocoin">
  <img src="https://img.shields.io/badge/Android App-eb00cb.svg?style=for-the-badge&logo=Android" /></a>
<a href="https://github.com/revoxhere/duino-coin/blob/gh-pages/assets/whitepaper.pdf">
  <img src="https://img.shields.io/badge/whitepaper-ff0095.svg?style=for-the-badge&logo=Academia" /></a>
<a href="https://youtu.be/im0Tca7EjrA">
  <img src="https://img.shields.io/badge/Video-Watch-ff0064.svg?style=for-the-badge&logo=Youtube" /></a>
<a href="https://discord.gg/kvBkccy">
  <img src="https://img.shields.io/discord/677615191793467402.svg?color=ff283a&label=Discord&logo=Discord&style=for-the-badge" /></a>
<a href="https://github.com/revoxhere/duino-coin/releases/latest">
  <img src="https://img.shields.io/badge/release-latest-ff640a.svg?style=for-the-badge" /></a>
<br>

# Duino 코인 한글 번역본

<h3>
Duino-Coin은 Arduinos, ESP8266/32 보드, 라즈베리 파이, 컴퓨터 등으로 채굴할 수 있는 코인입니다 (Wi-Fi 라우터, 스마트 TV, 스마트폰, 스마트워치, SBC, MCU 또는 GPU 포함).
</h3>


| 주요 특징 | 사용된 기술 | 지원되는 보드 |
|-|-|-|
| 💻 다양한 플랫폼 지원<br>👥 빠르게 성장하는 커뮤니티<br>💱 쉬운 사용 및 교환<br>(DUCO Exchange, Node-S, JustSwap, SushiSwap에서)<br>🌎 어디서든지 사용 가능<br>:new: 완전히 독창적인 오픈 소스 프로젝트<br>🌳 초보자 친화적 및 친환경적<br>💰 효율적인 비용과 쉬운 채굴 | ⚒️ 알고리즘: DUCO-S1, XXHASH, 이외 <br>추가 예정 (PoS 포함)<br>♐ 보상: 채굴자에게 공정한 보상을 제공하는<br>"Kolka" 시스템<br>⚡ 거래 시간: 즉시<br>🪙 코인 공급량: 무제한<br>(2020년 12월 이전: 350k 코인)<br>(향후 새로운 한도 계획 예정)<br>🔤 시세: DUCO (ᕲ)<br>🔢 소수점: 최대 20 | ♾️ Arduinos<br>(Uno, Nano, Mega, Due, Pro Mini 등)<br>📶 ESP8266s<br>(NodeMCU, Wemos 등)<br>📶 ESP32s<br>(ESP-WROOM, ESP32-CAM 등)<br>🍓 라즈베리파이<br>(1, 2, Zero (W/WH), 3, 4, Pico, 400)<br>🍊 오렌지 파이<br>(Zero, Zero 2, PC, Plus 등)<br>⚡ Teensy 4.1 보드 |


## 시작하기

#### Duino-Coin을 시작하는 가장 쉬운 방법은 OS에 대한 [최신 릴리스](https://github.com/revoxhere/duino-coin/releases/latest)를 다운로드하는 것 입니다.<br>
운영체제(윈도우 혹은 리눅스 등)에 맞는 릴리스를 다운로드한 후 압축을 풀고 원하는 프로그램을 실행합니다.<br>
이 과정에서는 추가로 다른 프로그램을 설치할 필요가 없습니다.


도움이 필요하면 공식 웹사이트에 있는 <a href="https://duinocoin.com/getting-started">공식 시작 가이드</a>를 참조하세요.<br>
FAQ 및 문제 해결 도움말은 [Wikis](https://github.com/revoxhere/duino-coin/wiki)에서 찾을 수 있습니다.<br>

### 설치 매뉴얼

#### Linux (데비안 계열)

```BASH
sudo apt update
sudo apt install python3 python3-pip git python3-pil python3-pil.imagetk -y # dependency 설치
git clone https://github.com/revoxhere/duino-coin # Duino-Coin 저장소 복제(clone repository)
cd duino-coin
python3 -m pip install -r requirements.txt # pip dependencies 설치
````

이 작업을 수행한 후 소프트웨어(예: python3 PC_Miner.py)를 시작하는 것을 추천드립니다.


#### Windows

1. [Python 3](https://www.python.org/downloads/) 다운로드 및 설치(PATH에 Python 및 Pip을 추가해야 함)
2. [Duino-Coin repository](https://github.com/revoxhere/duino-coin/archive/master.zip) 다운로드
3. 다운로드한 zip 아카이브의 압축을 풀고 명령 프롬프트에서 폴더를 엽니다.
4. 명령 프롬프트에 `py -m pip install -r requirements.txt` 를 입력하여 필요한 pip dependency를 설치합니다.

이 작업을 수행한 후 소프트웨어를 시작할 수 있습니다.(원하는 `.py` 파일을 두 번 클릭하거나`py PC_Miner.py` 을 명령 프롬프트에 입력합니다.)

## DUCO & wDUCO

Duino-Coin은 하이브리드 통화입니다. 즉, wDUCO로 변환될 수 있으며, 이는 [Tron](https://tron.network) 네트워크에서 DUCO(토큰)로 래핑될 수 있다는 의미입니다. 현재는 external wallet에 자금을 저장하거나 JustSwap에서 wDUCO를 다른 토큰으로 교환하는 것 외에는 많이 사용되지 않습니다. wDUCO 사용에 대한 튜토리얼은 [wDUCO wiki](https://github.com/revoxhere/duino-coin/wiki/wDUCO-tutorial)에서 확인할 수 있습니다.


## 개발

Contribution(기여)을 통해 오픈소스 커뮤니티를 배우고, 영감을 주고, 창조할 수 있는 놀라운 장소로 만들 수 있습니다.<br>
Duino-Coin 프로젝트에 대한 기여해 주시면 감사하겠습니다.

프로젝트에 어떻게 contribution(기여)할 수 있나요?

*   프로젝트 fork
*   기능 branch 만들기
*   변경 사항 commit
*   정상 작동 확인
*   pull request 열기

서버 소스 코드, API 호출에 대한 문서 및 Duino-Coin용 앱 개발을 위한 공식 라이브러리는 [useful tools](https://github.com/revoxhere/duino-coin/tree/useful-tools) branch에서 사용할 수 있습니다.

## 공식적으로 테스트 된 장치 및 보드 벤치마크

<details>
    <summary>
        테이블 길이가 매우 길어서 축소하였습니다. 확장하려면 이 텍스트를 눌러주세요
    </summary>

### 보상 정보는 다른 요인에 의해 달라질 수 있습니다.

| 장치/CPU/SBC/MCU/칩                                   | 평균 헤시레이트<br>(모든 쓰레드) | 마이닝<br>쓰레드 | 전력<br>사용량 | 평균<br>DUCO/일 |
|-----------------------------------------------------------|-----------------------------------|-------------------|----------------|---------------------|
| Arduino Pro Mini, Uno, Nano etc.<br>(Atmega 328p/pb/16u2) | 196 H/s                           | 1                 | 0.2 W          | 9-10                |
| Teensy 4.1 (soft cryptography)                            | 80 kH/s                           | 1                 | 0.5 W          | -                   |
| NodeMCU, Wemos D1 etc.<br>(ESP8266)                       | 10 kH/s (160MHz) 4.9 kH/s (80Mhz) | 1                 | 0.6 W          | 6-7                 |
| ESP32                                                     | 33 kH/s                           | 2                 | 1 W            | 8-9                 |
| Raspberry Pi Zero                                         | 18 kH/s                           | 1                 | 1.1 W          | -                   |
| Raspberry Pi 3                                            | 440 kH/s                          | 4                 | 5.1 W          | -                   |
| Raspberry Pi 4                                            | 740 kH/s (32bit)                  | 4                 | 6.4 W          | 10                  |
| ODROID XU4                                                | 1.0 MH/s                          | 8                 | 5 W            | 9                   |
| Atomic Pi                                                 | 690 kH/s                          | 4                 | 6 W            | -                   |
| Orange Pi Zero 2                                          | 740 kH/s                          | 4                 | 2.55 W         | -                   |
| Khadas Vim 2 Pro                                          | 1.12 MH/s                         | 8                 | 6.2 W          | -                   |
| Libre Computers Tritium H5CC                              | 480 kH/s                          | 4                 | 5 W            | -                   |
| Libre Computers Le Potato                                 | 410 kH/s                          | 4                 | 5 W            | -                   |
| Pine64 ROCK64                                             | 640 kH/s                          | 4                 | 5 W            | -                   |
| Intel Celeron G1840                                       | 1.25 MH/s                         | 2                 | -              | 5-6                 |
| Intel Core i5-2430M                                       | 1.18 MH/s                         | 4                 | -              | 6.5                 |
| Intel Core i5-3230M                                       | 1.52 MH/s                         | 4                 | -              | 7.2                 |
| Intel Core i5-5350U                                       | 1.35 MH/s                         | 4                 | -              | 6.0                 |
| Intel Core i5-7200U                                       | 1.62 MH/s                         | 4                 | -              | 7.5                 |
| Intel Core i5-8300H                                       | 3.67 MH/s                         | 8                 | -              | 9.1                 |   
| Intel Core i3-4130                                        | 1.45 MH/s                         | 4                 | -              | -                   |
| AMD Ryzen 5 2600                                          | 4.9 MH/s                          | 12                | 67 W           | 15.44               |

모든 성능 테스트는 DUCO-S1 알고리즘을 사용했습니다. 이 테이블을 지속적으로 업데이트 예정입니다. 
</details>

## 커뮤니티 제작 소프트웨어

<details>
    <summary>
        해당 리스트가 매우 길어서 축소되었습니다. 확장하려면 이 텍스트를 눌러주세요
    </summary>

아래 소프트웨어들은 당사가 개발한 것이 아니며, 사용으로 인해 계정이 차단되는 일에 대해 어떠한 보장을 하지 않습니다. 호기심으로만 봐주세요.

### Duino 코인에 사용 가능한 채굴기들:   
*   [DuinoCoinbyLabVIEW](https://github.com/ericddm/DuinoCoinbyLabVIEW) - 채굴을 위한 LabVIEW 제품 by ericddm
  *   [Duino-JS](https://github.com/Hoiboy19/Duino-JS) - 개인 사이트에 쉽게 적용 가능한 Javascript 채굴기 by Hoiboy19
  *   [Mineuino](https://github.com/VatsaDev/Mineuino) - 웹사이트 수익 창출 도구 by VatsaDev
  *   [hauchel's duco-related stuff repository](https://github.com/hauchel/duco/) - 다른 마이크로 컨트롤러에서 DUCO 채굴을 위한 코드 모음  
  *   [duino-coin-php-miner](https://github.com/ricardofiorani/duino-coin-php-miner) PHP를 이용한 도커화된 채굴기 by ricardofiorani
  *   [duino-coin-kodi](https://github.com/SandUhrGucker/duino-coin-kodi) - Kodi Media Center를 위한 채굴 애드온 by SandUhrGucker
  *   [MineCryptoOnWifiRouter](https://github.com/BastelPichi/MineCryptoOnWifiRouter) - 라우터에서 Duino-coin 채굴하는 Python 스크립트 by BastelPichi
  *   [Duino-Coin_Android_Cluster Miner](https://github.com/DoctorEenot/DuinoCoin_android_cluster) - 여러 장치를 최소한의 연결로 채굴 by DoctorEenot
  *   [ESPython DUCO Miner](https://github.com/fabiopolancoe/ESPython-DUCO-Miner) - ESP 보드용 MicroPython 채굴기 by fabiopolancoe
  *   [DUCO Miner for Nintendo 3DS](https://github.com/BunkerInnovations/duco-3ds) - Nintendo 3DS용 Python 채굴기 PhereloHD & HGEpro
  *   [Dockerized DUCO Miner](https://github.com/Alicia426/Dockerized_DUCO_Miner_minimal) - Docker 이용한 채굴기 by Alicia426
  *   [nonceMiner](https://github.com/colonelwatch/nonceMiner) - 가장 빠른 Duino-Coin 채굴기 by colonelwatch
  *   [NodeJS-DuinoCoin-Miner](https://github.com/DarkThinking/NodeJS-DuinoCoin-Miner/) - 간단한 NodeJS 채굴기 by DarkThinking
  *   [d-cpuminer](https://github.com/phantom32-0/d-cpuminer) - 퓨어 C 채굴기 by phantom32 & revoxhere
  *   [Go Miner](https://github.com/yippiez/go-miner) by yippiez
  *   [ducominer](https://github.com/its5Q/ducominer) by its5Q
  *   [Unofficial miners directory](https://github.com/revoxhere/duino-coin/tree/master/Unofficial%20miners)
      *   [Julia Miner](https://github.com/revoxhere/duino-coin/blob/master/Unofficial%20miners/Julia_Miner.jl) by revoxhere
      *   [Ruby Miner](https://github.com/revoxhere/duino-coin/blob/master/Unofficial%20miners/Ruby_Miner.rb) by revoxhere
      *   [Minimal Python Miner (DUCO-S1)](https://github.com/revoxhere/duino-coin/blob/master/Unofficial%20miners/Minimal_PC_Miner.py) by revoxhere
      *   [Minimal Python Miner (XXHASH)](https://github.com/revoxhere/duino-coin/blob/master/Unofficial%20miners/Minimal_PC_Miner_XXHASH.py) by revoxhere
      *   [Teensy 4.1 code for Arduino IDE](https://github.com/revoxhere/duino-coin/blob/master/Unofficial%20miners/Teensy_code/Teensy_code.ino) by joaquinbvw

  ### 기타 도구:
  *   [DuinoCoin-balance-Home-Assistant](https://github.com/NL647/DuinoCoin-balance-Home-Assistant) - 홈 어시스턴트 용 잔액 표시 애드온 by NL647
  *   [Duino Coin Status Monitor](https://github.com/TSltd/duino_coin) 128x64 SSD1306 OLED 와 ESP8266 용 by TSltd
  *   [ducopanel](https://github.com/ponsato/ducopanel) - Duino 코인 채굴기 제어하기 위한 GUI 앱 by ponsato
  *   [Duino AVR Monitor](https://www.microsoft.com/store/apps/9NJ7HPFSR9V5) - DUCO 채굴하는 AVR 장치들 모니터링하기 위한 GUI Windows 앱 by niknak
  *   [Duino-Coin Arduino library](https://github.com/ricaun/arduino-DuinoCoin) by ricaun
  *   [DuinoCoinI2C](https://github.com/ricaun/DuinoCoinI2C) - ESP8266/ESP32 를 master로 사용하는 아두이노 by ricaun
  *   [Duino-Coin Mining Dashboard](https://lulaschkas.github.io/duco-mining-dashboard/) 문제 해결 도우미 by Lulaschkas
  *   [duco-miners](https://github.com/dansinclair25/duco-miners) CLI 채굴 대쉬보드 by dansinclair25
  *   [Duco-Coin Symbol Icon ttf](https://github.com/SandUhrGucker/Duco-Coin-Symbol-Icon-ttf-.h) by SandUhrGucker
  *   [DUCO Browser Extension](https://github.com/LDarki/DucoExtension) 크롬 및 파생 제품용 by LDarki
  *   [DUCO Monitor](https://siunus.github.io/duco-monitor/) 계정 통계 웹사이트 by siunus
  *   [duino-tools](https://github.com/kyngs/duino-tools) Java 작성 by kyngs
  *   [Duino Stats](https://github.com/Bilaboz/duino-stats) 공식 디스코드 봇 by Bilaboz
  *   [DuCoWallet](https://github.com/viktor02/DuCoWallet) GUI 지갑 by viktor02
  *   [Duco-widget-ios](https://github.com/naphob/duco-widget-ios) - Duino 코인 iOS 위젯 by Naphob 

  비슷한 리스트를 [여기](https://duinocoin.com/apps) 에서도 볼 수 있습니다.
</details>


## 라이센스
Duino-Coin은 대부분 MIT 라이센스에 따라 배포됩니다. 자세한 내용은 `LICENSE` 파일을 참조하십시오. 일부 타사 파일에는 다른 라이센스를 가질 수 있습니다 - 해당 부분은 `LICENSE` 설명을 참고해 주세요. (주로 소스코드 파일 상단에 있음)



## 서비스 약관
1. Duino-Coins ("DUCOs")은 채굴이라는 프로세스를 통해 채굴자가 코인을 얻습니다.<br/>
2. 채굴은 DUCO-S1 (and XXHASH) 알고리즘(<a href="https://github.com/revoxhere/duino-coin/blob/gh-pages/assets/whitepaper.pdf">Duino-Coin Whitepaper</a> 설명 참조)을 사용하는 것으로 설명되며, 여기서 수학 문제의 올바른 답을 찾으면 채굴자에게 보상을 제공합니다.<br/>
3. 채굴은 공식적으로 CPU, AVR 보드(예: Arduino 보드), 싱글 보드 컴퓨터(예: Raspberry Pi 보드), ESP32/8266 보드를 사용하여 채굴할 수 있습니다.(기타 공식적으로 허용되는 채굴기는 README 상단에 설명되어 있습니다.)<br/>
4. GPU, FPGA 및 기타 고효율 하드웨어에서 채굴이 허용되지만, 'EXTREME' 채굴 난이도만 사용합니다.<br/>
5. 자신의 하드웨어에 적합하지 않은 난이도의 채굴기(<a href="https://github.com/revoxhere/duino-coin/tree/useful-tools#socket-api">difficulty list</a> 참조)를 사용하는 모든 사용자에게는 올바른 채굴 난이도로 자동으로 조절됩니다.<br/>
6. 적합한 난이도보다 낮은 난이도를 계속 사용하려고 하는 사용자는 일시적으로 차단될 수 있습니다.<br/>
7. 금지는 계정 제거와 함께 사용자가 자신의 코인에 엑세스하는 것을 차단하는 것입니다.<br/>
8. 합법적으로 획득한 코인만 교환이 가능합니다.<br/>
9. 서비스 약관 위반(또는 남용)을 조사하기 위해 계정이 일시적으로 정지될 수 있습니다. <br/>
10. DUCO-Exchange("공식 거래소")에 대한 교환 요청은 서비스 약관 위반 조사 중에 지연 및/또는 거부될 수 있습니다. <br/>
11. 공식 거래소에 대한 교환 요청은 서비스 약관 위반 및/또는 자금 부족으로 인해 거부될 수 있습니다.<br/>
12. 무료 클라우드 호스팅 서비스(또는 무료 VPS 서비스 - 예: Repl.it, GitHub Actions 등)로 채굴하는 것은 불공정하므로 허용되지 않습니다.<br/>
13. 위반 사항이 입증될 경우 사용자의 DUCO가 소멸될 수 있습니다.<br/>
14. 이 서비스 약관은 사전 통지 없이 언제든지 변경될 수 있습니다.<br/>
15. 여러 계정으로 코인을 채굴하는 것 등의 합리적이지 않은 이유로 부계정을 갖는 것은 허용되지 않습니다.<br/>
16. Duino-Coin을 사용하는 모든 사용자는 위의 규칙을 준수하는 데 동의합니다.<br/>


## 개인 정보 정책
1. master 서버에는 사용자의 이름, 해시된 비밀번호(bcrypt를 이용), 계정 생성 날짜 및 사용자의 이메일만 데이터로 저장됩니다.<br/>
2. 이메일은 공개적으로 사용할 수 없으며, <a href="https://revoxhere.github.io/duco-exchange/">DUCO-Exchange</a> 에서 교환을 확인하고 비정기적인 뉴스레터(향후 계획)를 수신하는 등 필요시 사용자에게 연락할 때만 사용됩니다.<br/>
3. 잔액, 거래 및 채굴 관련 데이터는  <a href="https://github.com/revoxhere/duino-coin/tree/useful-tools#http-json-api">JSON APIs</a> 에서 공개적으로 사용할 수 있습니다. </br>
4. 개인 정보 정책은 추후 사전 공지를 통해 변경될 수 있습니다.

## 주요 프로젝트 관리자

*   [@revoxhere](https://github.com/revoxhere/) - robik123.345@gmail.com ( Python 리드 개발자, 프로젝트 설립자)
*   [@Bilaboz](https://github.com/bilaboz/) (NodeJS 리드 개발자)
*   [@connorhess](https://github.com/connorhess) (Python 리드 개발자, Node-S 소유자)
*   [@JoyBed](https://github.com/JoyBed) (AVR 리드 개발자)
*   [@Yennefer](https://www.instagram.com/vlegle/) (소셜 관리자)
*   [@Tech1k](https://github.com/Tech1k/) - hello@kristiankramer.net (리드 Webmaster 및 DUCO 개발자)
*   [@ygboucherk](https://github.com/ygboucherk) ([wDUCO](https://github.com/ygboucherk/wrapped-duino-coin-v2) 개발자)
*   [@Lulaschkas](https://github.com/Lulaschkas) (개발자)
*   [@joaquinbvw](https://github.com/joaquinbvw) (AVR 개발자)


Duino-Coin 프로젝트 개발에 도움을 주신 모든 [contributors](https://github.com/revoxhere/duino-coin/graphs/contributors) 에게 크나큰 감사를 드립니다.


<hr>

프로젝트 Link: [https://github.com/revoxhere/duino-coin/](https://github.com/revoxhere/duino-coin/)
<br/>
웹사이트 Link: [https://duinocoin.com/](https://duinocoin.com/)




